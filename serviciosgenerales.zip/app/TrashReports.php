<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrashReports extends Model
{
    //
}
